using System;
using System.IO.Ports;
using System.Windows.Forms;

namespace YourNamespace
{
    public partial class FormeEnvoi : Form
    {
        private SerialPort serialPort;

        public FormeEnvoi()
        {
            InitializeComponent();
            LoadPorts();
            serialPort = new SerialPort();
        }

        private void LoadPorts()
        {
            comboBoxPorts.Items.Clear();
            foreach (string port in SerialPort.GetPortNames())
            {
                comboBoxPorts.Items.Add(port);
            }
            if (comboBoxPorts.Items.Count > 0)
                comboBoxPorts.SelectedIndex = 0;
        }

        private void btnOuvrir_Click(object sender, EventArgs e)
        {
            if (serialPort.IsOpen)
            {
                serialPort.Close();
                btnOuvrir.Text = "Ouvrir";
            }
            else
            {
                try
                {
                    serialPort.PortName = comboBoxPorts.SelectedItem.ToString();
                    serialPort.BaudRate = 9600;
                    serialPort.DataBits = 8;
                    serialPort.Parity = Parity.None;
                    serialPort.StopBits = StopBits.One;
                    serialPort.Open();
                    btnOuvrir.Text = "Fermer";
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erreur lors de l'ouverture du port : " + ex.Message);
                }
            }
        }

        private void btnEnvoyer_Click(object sender, EventArgs e)
        {
            if (!serialPort.IsOpen)
            {
                MessageBox.Show("Veuillez ouvrir un port série.");
                return;
            }

            try
            {
                string message = txtD1.Text + ";" + txtD2.Text + "\n";
                serialPort.Write(message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de l'envoi : " + ex.Message);
            }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (serialPort.IsOpen)
                serialPort.Close();
            base.OnFormClosing(e);
        }
    }
} 