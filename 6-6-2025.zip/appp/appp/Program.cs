using System;
using System.Windows.Forms;

namespace appp
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();
            
            // Créer et afficher les deux formulaires
            var formEnvoi = new FormeEnvoi();
            var formReception = new FormeReception();
            
            formEnvoi.Show();
            formReception.Show();
            
            Application.Run();
        }
    }
}