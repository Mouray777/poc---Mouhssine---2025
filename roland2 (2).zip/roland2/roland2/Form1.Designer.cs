﻿namespace Roland2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            comboBoxSend = new ComboBox();
            comboBoxReceive = new ComboBox();
            textBoxMessage = new TextBox();
            buttonSend = new Button();
            listBoxReceived = new ListBox();
            buttonConnect = new Button();
            buttonRefresh = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            SuspendLayout();
            // 
            // comboBoxSend
            // 
            comboBoxSend.FormattingEnabled = true;
            comboBoxSend.Location = new Point(14, 29);
            comboBoxSend.Margin = new Padding(4, 3, 4, 3);
            comboBoxSend.Name = "comboBoxSend";
            comboBoxSend.Size = new Size(140, 23);
            comboBoxSend.TabIndex = 0;
            // 
            // comboBoxReceive
            // 
            comboBoxReceive.FormattingEnabled = true;
            comboBoxReceive.Location = new Point(14, 75);
            comboBoxReceive.Margin = new Padding(4, 3, 4, 3);
            comboBoxReceive.Name = "comboBoxReceive";
            comboBoxReceive.Size = new Size(140, 23);
            comboBoxReceive.TabIndex = 1;
            // 
            // textBoxMessage
            // 
            textBoxMessage.Location = new Point(14, 121);
            textBoxMessage.Margin = new Padding(4, 3, 4, 3);
            textBoxMessage.Name = "textBoxMessage";
            textBoxMessage.Size = new Size(233, 23);
            textBoxMessage.TabIndex = 2;
            // 
            // buttonSend
            // 
            buttonSend.Location = new Point(14, 151);
            buttonSend.Margin = new Padding(4, 3, 4, 3);
            buttonSend.Name = "buttonSend";
            buttonSend.Size = new Size(88, 27);
            buttonSend.TabIndex = 3;
            buttonSend.Text = "Envoyer";
            buttonSend.UseVisualStyleBackColor = true;
            buttonSend.Click += buttonSend_Click;
            // 
            // listBoxReceived
            // 
            listBoxReceived.FormattingEnabled = true;
            listBoxReceived.ItemHeight = 15;
            listBoxReceived.Location = new Point(13, 186);
            listBoxReceived.Margin = new Padding(4, 3, 4, 3);
            listBoxReceived.Name = "listBoxReceived";
            listBoxReceived.Size = new Size(233, 109);
            listBoxReceived.TabIndex = 4;
            // 
            // buttonConnect
            // 
            buttonConnect.Location = new Point(14, 301);
            buttonConnect.Margin = new Padding(4, 3, 4, 3);
            buttonConnect.Name = "buttonConnect";
            buttonConnect.Size = new Size(88, 27);
            buttonConnect.TabIndex = 5;
            buttonConnect.Text = "Connecter";
            buttonConnect.UseVisualStyleBackColor = true;
            buttonConnect.Click += buttonConnect_Click;
            // 
            // buttonRefresh
            // 
            buttonRefresh.Location = new Point(108, 301);
            buttonRefresh.Margin = new Padding(4, 3, 4, 3);
            buttonRefresh.Name = "buttonRefresh";
            buttonRefresh.Size = new Size(88, 27);
            buttonRefresh.TabIndex = 6;
            buttonRefresh.Text = "Rafraîchir";
            buttonRefresh.UseVisualStyleBackColor = true;
            buttonRefresh.Click += buttonRefresh_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(14, 10);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(108, 15);
            label1.TabIndex = 7;
            label1.Text = "Port COM d'envoi :";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(14, 57);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(135, 15);
            label2.TabIndex = 8;
            label2.Text = "Port COM de réception :";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(14, 103);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(113, 15);
            label3.TabIndex = 9;
            label3.Text = "Message à envoyer :";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(14, 166);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(95, 15);
            label4.TabIndex = 10;
            label4.Text = "Messages reçus :";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(14, 331);
            label5.Name = "label5";
            label5.Size = new Size(198, 15);
            label5.TabIndex = 11;
            label5.Text = "LabSerial-1-Mouhssine Rayane-2025";
            label5.Click += label5_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(331, 355);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(buttonRefresh);
            Controls.Add(buttonConnect);
            Controls.Add(listBoxReceived);
            Controls.Add(buttonSend);
            Controls.Add(textBoxMessage);
            Controls.Add(comboBoxReceive);
            Controls.Add(comboBoxSend);
            Margin = new Padding(4, 3, 4, 3);
            Name = "Form1";
            Text = "Connexion COM";
            FormClosing += Form1_FormClosing;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.ComboBox comboBoxSend;
        private System.Windows.Forms.ComboBox comboBoxReceive;
        private System.Windows.Forms.TextBox textBoxMessage;
        private System.Windows.Forms.Button buttonSend;
        private System.Windows.Forms.ListBox listBoxReceived;
        private System.Windows.Forms.Button buttonConnect;
        private System.Windows.Forms.Button buttonRefresh;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private Label label5;
    }
}
