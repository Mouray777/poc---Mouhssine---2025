using System;
using System.IO.Ports;
using System.Windows.Forms;

namespace Roland2
{
    public partial class FormReception : Form
    {
        private SerialPort serialPort;

        public FormReception()
        {
            InitializeComponent();
            serialPort = new SerialPort();
        }

        private void InitializeComponent()
        {
            this.txtMessagesRecus = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // txtMessagesRecus
            // 
            this.txtMessagesRecus.Location = new System.Drawing.Point(12, 12);
            this.txtMessagesRecus.Multiline = true;
            this.txtMessagesRecus.Name = "txtMessagesRecus";
            this.txtMessagesRecus.ReadOnly = true;
            this.txtMessagesRecus.Size = new System.Drawing.Size(260, 237);
            this.txtMessagesRecus.TabIndex = 0;
            // 
            // FormReception
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.txtMessagesRecus);
            this.Name = "FormReception";
            this.Text = "Réception de messages";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormReception_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.TextBox txtMessagesRecus;

        public void ConnecterPort(string portName)
        {
            try
            {
                if (serialPort.IsOpen)
                {
                    serialPort.Close();
                }

                serialPort.PortName = portName;
                serialPort.BaudRate = 9600;
                serialPort.DataReceived += SerialPort_DataReceived;
                serialPort.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur de connexion: " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void DeconnecterPort()
        {
            if (serialPort.IsOpen)
            {
                serialPort.Close();
            }
        }

        private void SerialPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            try
            {
                string message = serialPort.ReadLine();
                AjouterMessage("Reçu: " + message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur de réception: " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void AjouterMessage(string message)
        {
            if (txtMessagesRecus.InvokeRequired)
            {
                txtMessagesRecus.Invoke(new Action<string>(AjouterMessage), message);
                return;
            }

            txtMessagesRecus.AppendText(message + Environment.NewLine);
        }

        private void FormReception_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (serialPort.IsOpen)
            {
                serialPort.Close();
            }
        }
    }
} 