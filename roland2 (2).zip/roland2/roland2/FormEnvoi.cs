using System;
using System.IO.Ports;
using System.Windows.Forms;

namespace Roland2
{
    public partial class FormEnvoi : Form
    {
        private FormReception formReception;
        private SerialPort serialPortEnvoi;
        private Label label1;
        private SerialPort serialPortReception;

        public FormEnvoi()
        {
            InitializeComponent();
            serialPortEnvoi = new SerialPort();
            serialPortReception = new SerialPort();
            ChargerPortsCOM();
        }

        private void InitializeComponent()
        {
            txtMessage = new TextBox();
            btnEnvoyer = new Button();
            cmbPortEnvoi = new ComboBox();
            btnConnecter = new Button();
            lblPortEnvoi = new Label();
            cmbPortReception = new ComboBox();
            lblPortReception = new Label();
            label1 = new Label();
            SuspendLayout();
            // 
            // txtMessage
            // 
            txtMessage.Location = new Point(14, 138);
            txtMessage.Margin = new Padding(4, 3, 4, 3);
            txtMessage.Multiline = true;
            txtMessage.Name = "txtMessage";
            txtMessage.Size = new Size(303, 115);
            txtMessage.TabIndex = 0;
            // 
            // btnEnvoyer
            // 
            btnEnvoyer.Enabled = false;
            btnEnvoyer.Location = new Point(14, 261);
            btnEnvoyer.Margin = new Padding(4, 3, 4, 3);
            btnEnvoyer.Name = "btnEnvoyer";
            btnEnvoyer.Size = new Size(303, 27);
            btnEnvoyer.TabIndex = 1;
            btnEnvoyer.Text = "Envoyer";
            btnEnvoyer.UseVisualStyleBackColor = true;
            btnEnvoyer.Click += btnEnvoyer_Click;
            // 
            // cmbPortEnvoi
            // 
            cmbPortEnvoi.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbPortEnvoi.FormattingEnabled = true;
            cmbPortEnvoi.Location = new Point(14, 29);
            cmbPortEnvoi.Margin = new Padding(4, 3, 4, 3);
            cmbPortEnvoi.Name = "cmbPortEnvoi";
            cmbPortEnvoi.Size = new Size(140, 23);
            cmbPortEnvoi.TabIndex = 2;
            // 
            // btnConnecter
            // 
            btnConnecter.Location = new Point(162, 27);
            btnConnecter.Margin = new Padding(4, 3, 4, 3);
            btnConnecter.Name = "btnConnecter";
            btnConnecter.Size = new Size(155, 27);
            btnConnecter.TabIndex = 3;
            btnConnecter.Text = "Connecter";
            btnConnecter.UseVisualStyleBackColor = true;
            btnConnecter.Click += btnConnecter_Click;
            // 
            // lblPortEnvoi
            // 
            lblPortEnvoi.AutoSize = true;
            lblPortEnvoi.Location = new Point(14, 10);
            lblPortEnvoi.Margin = new Padding(4, 0, 4, 0);
            lblPortEnvoi.Name = "lblPortEnvoi";
            lblPortEnvoi.Size = new Size(64, 15);
            lblPortEnvoi.TabIndex = 4;
            lblPortEnvoi.Text = "Port Envoi:";
            // 
            // cmbPortReception
            // 
            cmbPortReception.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbPortReception.FormattingEnabled = true;
            cmbPortReception.Location = new Point(14, 92);
            cmbPortReception.Margin = new Padding(4, 3, 4, 3);
            cmbPortReception.Name = "cmbPortReception";
            cmbPortReception.Size = new Size(140, 23);
            cmbPortReception.TabIndex = 5;
            // 
            // lblPortReception
            // 
            lblPortReception.AutoSize = true;
            lblPortReception.Location = new Point(14, 74);
            lblPortReception.Margin = new Padding(4, 0, 4, 0);
            lblPortReception.Name = "lblPortReception";
            lblPortReception.Size = new Size(88, 15);
            lblPortReception.TabIndex = 6;
            lblPortReception.Text = "Port Réception:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(100, 301);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(169, 15);
            label1.TabIndex = 7;
            label1.Text = "poc - Mouhssine Rayane- 2025";
            // 
            // FormEnvoi
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(331, 335);
            Controls.Add(label1);
            Controls.Add(lblPortReception);
            Controls.Add(cmbPortReception);
            Controls.Add(lblPortEnvoi);
            Controls.Add(btnConnecter);
            Controls.Add(cmbPortEnvoi);
            Controls.Add(btnEnvoyer);
            Controls.Add(txtMessage);
            Margin = new Padding(4, 3, 4, 3);
            Name = "FormEnvoi";
            Text = "Envoi de message";
            FormClosing += FormEnvoi_FormClosing;
            ResumeLayout(false);
            PerformLayout();
        }

        private System.Windows.Forms.TextBox txtMessage;
        private System.Windows.Forms.Button btnEnvoyer;
        private System.Windows.Forms.ComboBox cmbPortEnvoi;
        private System.Windows.Forms.Button btnConnecter;
        private System.Windows.Forms.Label lblPortEnvoi;
        private System.Windows.Forms.ComboBox cmbPortReception;
        private System.Windows.Forms.Label lblPortReception;

        public void SetFormReception(FormReception form)
        {
            formReception = form;
        }

        private void ChargerPortsCOM()
        {
            string[] ports = SerialPort.GetPortNames();
            
            cmbPortEnvoi.Items.Clear();
            cmbPortEnvoi.Items.AddRange(ports);
            if (ports.Length > 0)
                cmbPortEnvoi.SelectedIndex = 0;

            cmbPortReception.Items.Clear();
            cmbPortReception.Items.AddRange(ports);
            if (ports.Length > 1)
                cmbPortReception.SelectedIndex = 1;
            else if (ports.Length > 0)
                cmbPortReception.SelectedIndex = 0;
        }

        private void btnConnecter_Click(object sender, EventArgs e)
        {
            try
            {
                if (serialPortEnvoi.IsOpen)
                {
                    serialPortEnvoi.Close();
                    serialPortReception.Close();
                    formReception?.DeconnecterPort();
                    btnConnecter.Text = "Connecter";
                    btnEnvoyer.Enabled = false;
                }
                else
                {
                    // Connexion du port d'envoi
                    string portEnvoi = cmbPortEnvoi.SelectedItem.ToString();
                    serialPortEnvoi.PortName = portEnvoi;
                    serialPortEnvoi.BaudRate = 9600;
                    serialPortEnvoi.Open();

                    // Connexion du port de réception
                    string portReception = cmbPortReception.SelectedItem.ToString();
                    serialPortReception.PortName = portReception;
                    serialPortReception.BaudRate = 9600;
                    serialPortReception.DataReceived += SerialPortReception_DataReceived;
                    serialPortReception.Open();

                    formReception?.ConnecterPort(portReception);
                    btnConnecter.Text = "Déconnecter";
                    btnEnvoyer.Enabled = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur de connexion: " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void SerialPortReception_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            try
            {
                string message = serialPortReception.ReadLine();
                if (formReception != null)
                {
                    formReception.Invoke(new Action(() =>
                    {
                        formReception.AjouterMessage("Reçu: " + message);
                    }));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur de réception: " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnEnvoyer_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtMessage.Text) && serialPortEnvoi.IsOpen)
            {
                try
                {
                    serialPortEnvoi.WriteLine(txtMessage.Text);
                    if (formReception != null)
                    {
                        formReception.Invoke(new Action(() =>
                        {
                            formReception.AjouterMessage("Envoyé: " + txtMessage.Text);
                        }));
                    }
                    txtMessage.Clear();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erreur d'envoi: " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void FormEnvoi_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (serialPortEnvoi.IsOpen)
            {
                serialPortEnvoi.Close();
            }
            if (serialPortReception.IsOpen)
            {
                serialPortReception.Close();
            }
            formReception?.DeconnecterPort();
        }
    }
} 