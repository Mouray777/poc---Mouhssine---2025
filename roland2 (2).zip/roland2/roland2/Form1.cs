using System;
using System.IO.Ports;
using System.Windows.Forms;

namespace Roland2
{
    public partial class Form1 : Form
    {
        private SerialPort serialPortSend;
        private SerialPort serialPortReceive;

        public Form1()
        {
            InitializeComponent();
            RefreshPorts();
        }

        private void RefreshPorts()
        {
            comboBoxSend.Items.Clear();
            comboBoxReceive.Items.Clear();
            comboBoxSend.Items.AddRange(SerialPort.GetPortNames());
            comboBoxReceive.Items.AddRange(SerialPort.GetPortNames());
        }

        private void buttonConnect_Click(object sender, EventArgs e)
        {
            try
            {
                if (comboBoxSend.SelectedItem == null || comboBoxReceive.SelectedItem == null)
                {
                    MessageBox.Show("Veuillez sélectionner les deux ports COM.");
                    return;
                }

                serialPortSend = new SerialPort(comboBoxSend.SelectedItem.ToString(), 9600);
                serialPortReceive = new SerialPort(comboBoxReceive.SelectedItem.ToString(), 9600);

                serialPortReceive.DataReceived += SerialPortReceive_DataReceived;

                serialPortSend.Open();
                serialPortReceive.Open();

                MessageBox.Show("Ports connectés avec succès !");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de la connexion : " + ex.Message);
            }
        }

        private void buttonSend_Click(object sender, EventArgs e)
        {
            if (serialPortSend != null && serialPortSend.IsOpen)
            {
                serialPortSend.WriteLine(textBoxMessage.Text);
            }
            else
            {
                MessageBox.Show("Port d'envoi non ouvert.");
            }
        }

        private void SerialPortReceive_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            string message = serialPortReceive.ReadLine();
            Invoke(new Action(() => listBoxReceived.Items.Add(message)));
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            serialPortSend?.Close();
            serialPortReceive?.Close();
        }

        private void buttonRefresh_Click(object sender, EventArgs e)
        {
            RefreshPorts();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}
