# LabSerial-1-Mouhssine Rayane-2025

Ce projet est une application de communication série développée dans le cadre d'un laboratoire.

## Description
Application de communication série permettant l'envoi et la réception de messages via une interface graphique Windows Forms.

## Fonctionnalités
- Interface d'envoi de messages
- Interface de réception de messages
- Communication série bidirectionnelle

## Technologies utilisées
- C#
- Windows Forms
- .NET Framework 